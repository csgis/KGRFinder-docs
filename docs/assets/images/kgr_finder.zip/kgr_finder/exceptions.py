class StopProcessingException(Exception):
    pass