# KGR Finder plugin for QGIS

Everything you need to know:

**Docs:** https://kgr-finder-docs.csgis.de/


**Lisence:** https://www.gnu.org/licenses/gpl-3.0.en.html
